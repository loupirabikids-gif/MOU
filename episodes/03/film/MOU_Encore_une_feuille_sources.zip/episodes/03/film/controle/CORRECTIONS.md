# Corrections retenues — Encore une feuille

## Scénario accepté

Le retour utilisateur demande de répéter tout le cycle, y compris l’ouverture
du robinet et le lavage, après chaque contact de cuisine. La v1 avec un lavage
isolé est remplacée par la chronologie v2 : trois cycles complets après remuage,
tomate et contact avec le manche propre. Pas de nouvelle chute ajoutée.

## Premières images et correction du lavabo

Les28images de préparation montrent un défaut réel : le bras cache le bec et
le filet. Descendre la prise sous le bec ne suffit pas. La pose retenue réoriente
le même bras natif autour de l’axe épaule/prise par une isométrie : la courbe
passe sous l’évier et le filet reste visible jusqu’à la moufle. Les positions
de prise et la longueur du bras sont conservées. Cette pose est limitée aux
plans de lavage, les autres gestes gardent leur articulation habituelle.

La critique retrouve deux bouts de trait flottants à la racine du bras. Le
raccord d’encre est calculé aux intersections avec le contour réel du corps,
dans un rayon local maximal de24unités autour de l’épaule. Aucun masque n’est
ajouté ; remplissage, extrémité de moufle, reste du bras et bras opposé restent
natifs. Les autres sources validées ne sont pas modifiées.

La commande conserve le contact de la main jusqu’à la fin de fermeture et
l’eau s’arrête à cet instant :6.10s,13.85s,20.65s. Les timings sonores restent
les mêmes. La bande tirée garde une quantité excessive lisible et perforée.

## Papier et cadrage poubelle

Le rayon et l’orientation finale des boulettes sont communs au papier tenu,
au vol et à la pose. Les boulettes déjà arrivées persistent. Les silhouettes
sont légèrement irrégulières et se soutiennent dans une petite corbeille ajourée.

Les premières vues zoomées exposaient le bord inférieur du décor. Le cadrage
est borné à l’intérieur de l’image approuvée ; celle-ci n’est pas repeinte.
Même axe et même zoom à chaque arrivée, avec temps de lecture du nouveau niveau.

## Animatique puis cuillère finale

L’animatique V4 complète fait26s à12images/s, avec son. Son fichier et les
empreintes de fabrication sont conservés. La source V4 examinée est archivée
dans `versions/animation_animatique_v4.py.txt`.

L’audit détecte une variation de longueur de cuillère jusqu’à4.96px dans le
dernier geste. La V5 projette seulement l’extrémité de cuillère à135px de sa
prise sur les huit dernières images ; elle reste dans la poêle. Tous les autres
états sont identiques à V4. Le contrôle du final et la critique du vrai montage
sont conservés séparément de ce journal de décisions.

## Contrelecture du transport de tomate

La revue des312images décodées de l’animatique révèle que la portion de tomate
est masquée par la moufle pendant le transport, vers10.25–10.67s. Le compositeur
place cette portion devant la moufle uniquement pendant sa prise et son vol,
de10.05à10.85s. Les positions, le bras et le mouvement restent identiques.
Sur la coupelle et dans la poêle, les calques habituels sont conservés.

Une contrelecture de19images réellement décodées du MP4 v2 confirme la portion
visible, le lâcher puis son arrivée dans la poêle, ainsi que la fin corrigée de
cuillère. Aucun nouveau changement narratif ou de modèle n’est retenu avant
l’export1080×1920à24images/s.

## Retour utilisateur : lavabo et main uniquement

Après le premier montage livré au commit121beb3, l’utilisatrice préfère voir
uniquement un gros plan du lavabo et de la main pendant les lavages. Les trois
inserts sont recadrés sur le robinet, la cuve et la moufle, avec le bras original
entrant par la droite. Le corps, le visage et les accessoires d’îlot sont hors
de ces inserts. Aucun geste, trait de personnage ou effet sonore n’est modifié.

La comparaison des624scènes SVG avant/après confirme194images modifiées,
exclusivement dans les trois inserts de lavage, et430images strictement identiques
ailleurs. Animation, accessoires, son, rig et chronologie gardent leurs empreintes.
Les nouveaux contrôles sont `audit_scope_closeup.json` et la critique du gros plan.

## Retour suivant : raccord incomplet et main trop grande

Le réexamen demandé par l’utilisatrice retrouve un petit cran dans les plans
larges à0.5s,7.25s,17.625s et24.75s, ainsi qu’une cassure à2.75s et10.25s.
Le correctif précédent avait amélioré l’attache, sans supprimer totalement ce
défaut. Sa validation était trop large ; les nouveaux contrôles portent sur ces
vraies images du MP4, pas uniquement sur le lavabo qui masque la racine.

La nouvelle jonction extérieure rejoint la silhouette du corps en tangence,
avec une transition d’épaisseur du trait et une petite adaptation locale du
remplissage. L’extrémité de moufle, le trait intérieur, le bras droit et les
trajectoires restent conservés. Les six poses sont examinées en avant/après.

Dans les lavages, une réduction uniforme à70% du bras/main natif corrige la
disproportion face à la cuve. Le cadrage laisse la racine hors champ ; le contact
du jet et le placement de commande sont revus sur les rendus. Les premiers
essais créaient une pointe de racine visible et un petit vide sous le jet : ils
ne sont pas retenus. Aucun scénario, minutage ou bruitage n’est remplacé.
